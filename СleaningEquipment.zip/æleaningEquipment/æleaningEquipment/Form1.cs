﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace СleaningEquipment
{
    public partial class Form1 : Form
    {
        List<CEquip> cEquips = new List<CEquip>();
        public Form1()

        {
            InitializeComponent();
        }

        private void ShowDataFromList()
        {//метод, що виводить інформацію із списку в таблицю
            ElQuipGV.Rows.Clear();
            foreach (CEquip equip in cEquips)
            {
                string[] split = equip.OutputInfo().Split(new Char[] { '\t' });
                ElQuipGV.Rows.Add(split);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            AddForm form = new AddForm(cEquips);
            if (form.ShowDialog() == DialogResult.OK)
            {
                cEquips = form.List;
                ShowDataFromList();
            }
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            if (ElQuipGV.SelectedRows.Count > 0 &&
            ElQuipGV.SelectedRows[0].Index !=
            ElQuipGV.Rows.Count - 1)
            {
                CEquip Equip = (CEquip)cEquips[ElQuipGV.SelectedRows[0].Index];
                EditForm form = new EditForm(Equip);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    cEquips[ElQuipGV.SelectedRows[0].Index] = Equip;
                    ShowDataFromList();
                }
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (cEquips.Count == 0) return;
            if (MessageBox.Show("Видалити поточний запис?", "Видалення запису",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK &&
                ElQuipGV.SelectedRows.Count > 0 && ElQuipGV.SelectedRows[0].Index != ElQuipGV.Rows.Count - 1)
            {
                cEquips.RemoveAt(ElQuipGV.SelectedRows[0].Index);
                ElQuipGV.Rows.RemoveAt(ElQuipGV.SelectedRows[0].Index);
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            if (cEquips.Count == 0) return;
            if (MessageBox.Show("Очистити таблицю ?\n\"Всі дані будуть втрачені", "Очищення даних",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                cEquips.Clear();
                ElQuipGV.Rows.Clear();
            }
        }

        private void OpenTextButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog Open = new OpenFileDialog();
            Open.InitialDirectory = Application.StartupPath;
            Open.Filter = "Текстові файли (*.txt)|*.txt|All files (*.*)|*.*";
            Open.FileName = "CleaningEquipment.txt";
            Open.Title = "Прочитати дані";
            Open.FilterIndex = 1;
            Open.RestoreDirectory = true;
            StreamReader sr;
            if (Open.ShowDialog() == DialogResult.OK)
            {
                cEquips.Clear();
                sr = new StreamReader(Open.FileName,
                Encoding.UTF8);
                string s;
                try
                {
                    while ((s = sr.ReadLine()) != null)
                    {
                        string[] split = s.Split('\t');
                        if (split[0] == "Підлогомийна машина")
                        {
                            cEquips.Add(new FloorWash((split[1]), split[2],
                            Int32.Parse(split[3]), Int32.Parse(split[4]), double.Parse(split[5]), split[6],
                            Int32.Parse(split[7]), Int32.Parse(split[8]), split[9], Int32.Parse(split[10]), 
                            Double.Parse(split[11])));
                        } else
                        if (split[0] == "Електронний віник")
                        {
                            cEquips.Add(new ElBroom((split[1]), split[2],
                            Int32.Parse(split[3]), Int32.Parse(split[4]), double.Parse(split[5]), split[6],
                            Int32.Parse(split[7]), Int32.Parse(split[8]), split[9], Int32.Parse(split[10]), 
                            Double.Parse(split[11])));
                        } else
                        if (split[0] == "Міні мийка")
                        {
                            cEquips.Add(new MiniClean(split[1], split[2],
                            Int32.Parse(split[3]), Int32.Parse(split[4]), double.Parse(split[5]), split[6],
                            Int32.Parse(split[7]), Int32.Parse(split[8]), split[9], Int32.Parse(split[10]), 
                            Double.Parse(split[11])));
                        } else
                        if (split[0] == "Електроскребок")
                        {
                            cEquips.Add(new ElScraper(split[1], split[2],
                            Int32.Parse(split[3]), Int32.Parse(split[4]), double.Parse(split[5]), split[6],
                            Int32.Parse(split[7]), Int32.Parse(split[8]), split[9], Int32.Parse(split[10]),
                            Double.Parse(split[11])));
                        } else
                        if (split[0] == "Пароочищувач")
                        {
                            cEquips.Add(new SteamClean((split[1]), split[2],
                            Int32.Parse(split[3]), Int32.Parse(split[4]), double.Parse(split[5]), split[6],
                            Int32.Parse(split[7]), Int32.Parse(split[8]), split[9], Int32.Parse(split[10]), 
                            Double.Parse(split[11])));
                        } else
                        if (split[0] == "Пристрій для ч-ки терас")
                        {
                            cEquips.Add(new TerraceClean((split[1]), split[2],
                            Int32.Parse(split[3]), Int32.Parse(split[4]), double.Parse(split[5]), split[6],
                            Int32.Parse(split[7]), Int32.Parse(split[8]), split[9], Int32.Parse(split[10]), 
                            Double.Parse(split[11])));
                        } else
                        if (split[0] == "Віконний пилосос")
                        {
                            cEquips.Add(new FloorWash((split[1]), split[2],
                            Int32.Parse(split[3]), Int32.Parse(split[4]), double.Parse(split[5]), split[6],
                            Int32.Parse(split[7]), Int32.Parse(split[8]), split[9], Int32.Parse(split[10]), 
                            Double.Parse(split[11])));
                        }
                    }
                    ShowDataFromList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Сталась помилка: \n{0}",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sr.Close();
                }
            }
        }

        private void SaveTextButton_Click(object sender, EventArgs e)
        {
            if (cEquips.Count == 0) return;
            SaveFileDialog Save = new SaveFileDialog();
            Save.InitialDirectory = Application.StartupPath;
            Save.Filter = "Текстові файли (*.txt)|*.txt";
            Save.FileName = "CleaningEquipment.txt";
            Save.Title = "Зберегти дані";
            Save.FilterIndex = 1;
            Save.RestoreDirectory = true;
            StreamWriter sw;
            if (Save.ShowDialog() == DialogResult.OK)
            {
                sw = new StreamWriter(Save.FileName,
                false, Encoding.UTF8);
                try
                {
                    foreach (CEquip Equip in cEquips)
                    {
                        sw.Write(Equip.OutputInfo()+"\n");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Сталась помилка: \n{0}", ex.Message,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sw.Close();
                }
            }
        }

        private void FilterButton_Click(object sender, EventArgs e)
        {
            if (cEquips.Count == 0) return;
            int Min = ((CEquip)cEquips[0]).Volume;
            int Max = ((CEquip)cEquips[0]).Volume;
            foreach (CEquip equip in cEquips)
            {
                if (equip.Volume < Min) Min = equip.Volume;
                if (equip.Volume > Max) Max = equip.Volume;
            }
            FormFilter ff = new FormFilter(Min, Max);
            if (ff.ShowDialog() == DialogResult.OK)
            {
            StartOfLoop:
                for (int i = 0; i < cEquips.Count; i++)
                {
                    if ((((CEquip)cEquips[i]).Volume < ff.Min) ||
                    (((CEquip)cEquips[i]).Volume > ff.Max))
                    {
                        cEquips.RemoveAt(i);
                        goto StartOfLoop;
                    }
                }
                ShowDataFromList();
            }
        }

        private void SortComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cEquips.Count == 0) return;
            CEquipSortOrder SortOrder;
            switch (SortComboBox.SelectedIndex)
            {
                case 0:
                    SortOrder = CEquipSortOrder.SortByType;
                    break;
                case 1:
                    SortOrder = CEquipSortOrder.SortByManfct;
                    break;
                case 2:
                    SortOrder = CEquipSortOrder.SortByPower;
                    break;
                case 3:
                    SortOrder = CEquipSortOrder.SortByWW;
                    break;
                case 4:
                    SortOrder = CEquipSortOrder.SortByProd;
                    break;
                case 5:
                    SortOrder = CEquipSortOrder.SortBySA;
                    break;
                case 6:
                    SortOrder = CEquipSortOrder.SortByCost;
                    break;
                default:
                    SortOrder = CEquipSortOrder.SortByType;
                    break;
            }
            foreach (CEquip equip in cEquips)
                equip.SortOrder = SortOrder;
            List<CEquip> elequip = new List<CEquip>();
            foreach (CEquip equip in cEquips)
                elequip.Add(equip);
            elequip.Sort();
            cEquips.Clear();
            foreach (CEquip equips in elequip)
                cEquips.Add(equips);
            ShowDataFromList();
            ElQuipGV.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.MainWinWidth > 0)
                Width = Properties.Settings.Default.MainWinWidth;
            if (Properties.Settings.Default.MainWinHeight > 0)
                Height = Properties.Settings.Default.MainWinHeight;
            if (Properties.Settings.Default.MainWinLeft > 0)
                Left = Properties.Settings.Default.MainWinLeft;
            if (Properties.Settings.Default.MainWinTop > 0)
                Top = Properties.Settings.Default.MainWinTop;
            SortComboBox.SelectedIndex = Properties.Settings.Default.SortOrder;
            ElQuipGV.AutoGenerateColumns = false;
            DataGridViewColumn column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Type";
            column.HeaderText = "Тип";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Manufacturer";
            column.HeaderText = "Виробник";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Model";
            column.HeaderText = "Модель";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Power";
            column.HeaderText = "Потужність";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "WorkingWidth";
            column.HeaderText = "Робоча ширина";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Productivity";
            column.HeaderText = "Продуктивність";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "PowerSupply";
            column.HeaderText = "Тип живлення";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Volume";
            column.HeaderText = "Ємність";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Service_area";
            column.HeaderText = "Площа обслуговування";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Dimensions";
            column.HeaderText = "Габарити";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Weight";
            column.HeaderText = "Вага";
            ElQuipGV.Columns.Add(column);
            column = new DataGridViewTextBoxColumn();
            column.DataPropertyName = "Cost";
            column.HeaderText = "Вартість";
            ElQuipGV.Columns.Add(column);
            EventArgs args = new EventArgs();
            OnResize(args);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Закрити застосунок?", "Вихід з програми",
           MessageBoxButtons.OKCancel,
           MessageBoxIcon.Question) == DialogResult.OK)
                e.Cancel = false;
            else e.Cancel = true;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Properties.Settings.Default.MainWinWidth = Width;
            Properties.Settings.Default.MainWinHeight = Height;
            Properties.Settings.Default.MainWinLeft = Left;
            Properties.Settings.Default.MainWinTop = Top;
            Properties.Settings.Default.SortOrder = SortComboBox.SelectedIndex;
            Properties.Settings.Default.Save();
        }
    }
}
