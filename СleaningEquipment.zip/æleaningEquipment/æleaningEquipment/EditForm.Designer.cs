﻿namespace СleaningEquipment
{
    partial class EditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ProdText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.CostText = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.WeightText = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.DimensionsText = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ServAreaText = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.PowSupText = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.VolumeText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.WidthText = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PowerText = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ModelText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ManufactText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Cancl = new System.Windows.Forms.Button();
            this.Ok = new System.Windows.Forms.Button();
            this.TypeText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ProdText
            // 
            this.ProdText.Location = new System.Drawing.Point(34, 304);
            this.ProdText.Name = "ProdText";
            this.ProdText.Size = new System.Drawing.Size(147, 20);
            this.ProdText.TabIndex = 185;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 288);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 203;
            this.label7.Text = "Продуктивність";
            // 
            // CostText
            // 
            this.CostText.Location = new System.Drawing.Point(223, 258);
            this.CostText.Name = "CostText";
            this.CostText.Size = new System.Drawing.Size(147, 20);
            this.CostText.TabIndex = 190;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(220, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 202;
            this.label8.Text = "Ціна";
            // 
            // WeightText
            // 
            this.WeightText.Location = new System.Drawing.Point(223, 212);
            this.WeightText.Name = "WeightText";
            this.WeightText.Size = new System.Drawing.Size(147, 20);
            this.WeightText.TabIndex = 189;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(220, 196);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 201;
            this.label9.Text = "Вага";
            // 
            // DimensionsText
            // 
            this.DimensionsText.Location = new System.Drawing.Point(223, 166);
            this.DimensionsText.Name = "DimensionsText";
            this.DimensionsText.Size = new System.Drawing.Size(147, 20);
            this.DimensionsText.TabIndex = 188;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(220, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 200;
            this.label10.Text = "Габарити";
            // 
            // ServAreaText
            // 
            this.ServAreaText.Location = new System.Drawing.Point(223, 120);
            this.ServAreaText.Name = "ServAreaText";
            this.ServAreaText.Size = new System.Drawing.Size(147, 20);
            this.ServAreaText.TabIndex = 187;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(220, 104);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 13);
            this.label11.TabIndex = 199;
            this.label11.Text = "Площа використовування";
            // 
            // PowSupText
            // 
            this.PowSupText.Location = new System.Drawing.Point(223, 74);
            this.PowSupText.Name = "PowSupText";
            this.PowSupText.Size = new System.Drawing.Size(147, 20);
            this.PowSupText.TabIndex = 186;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(220, 58);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 13);
            this.label12.TabIndex = 198;
            this.label12.Text = "Тип живлення";
            // 
            // VolumeText
            // 
            this.VolumeText.Location = new System.Drawing.Point(34, 258);
            this.VolumeText.Name = "VolumeText";
            this.VolumeText.Size = new System.Drawing.Size(147, 20);
            this.VolumeText.TabIndex = 184;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 242);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 197;
            this.label5.Text = "Ємність";
            // 
            // WidthText
            // 
            this.WidthText.Location = new System.Drawing.Point(34, 212);
            this.WidthText.Name = "WidthText";
            this.WidthText.Size = new System.Drawing.Size(147, 20);
            this.WidthText.TabIndex = 183;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 13);
            this.label4.TabIndex = 196;
            this.label4.Text = "Ширина робочого елементу";
            // 
            // PowerText
            // 
            this.PowerText.Location = new System.Drawing.Point(34, 166);
            this.PowerText.Name = "PowerText";
            this.PowerText.Size = new System.Drawing.Size(147, 20);
            this.PowerText.TabIndex = 182;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 195;
            this.label3.Text = "Потужність";
            // 
            // ModelText
            // 
            this.ModelText.Location = new System.Drawing.Point(34, 120);
            this.ModelText.Name = "ModelText";
            this.ModelText.Size = new System.Drawing.Size(147, 20);
            this.ModelText.TabIndex = 181;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 194;
            this.label2.Text = "Модель";
            // 
            // ManufactText
            // 
            this.ManufactText.Location = new System.Drawing.Point(34, 81);
            this.ManufactText.Name = "ManufactText";
            this.ManufactText.Size = new System.Drawing.Size(147, 20);
            this.ManufactText.TabIndex = 180;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 193;
            this.label1.Text = "Виробник";
            // 
            // Cancl
            // 
            this.Cancl.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancl.Location = new System.Drawing.Point(302, 300);
            this.Cancl.Name = "Cancl";
            this.Cancl.Size = new System.Drawing.Size(68, 27);
            this.Cancl.TabIndex = 192;
            this.Cancl.Text = "Скасувати";
            this.Cancl.UseVisualStyleBackColor = true;
            this.Cancl.Click += new System.EventHandler(this.Cancl_Click);
            // 
            // Ok
            // 
            this.Ok.Location = new System.Drawing.Point(223, 300);
            this.Ok.Name = "Ok";
            this.Ok.Size = new System.Drawing.Size(68, 27);
            this.Ok.TabIndex = 191;
            this.Ok.Text = "Ок";
            this.Ok.UseVisualStyleBackColor = true;
            this.Ok.Click += new System.EventHandler(this.Ok_Click);
            // 
            // TypeText
            // 
            this.TypeText.Enabled = false;
            this.TypeText.Location = new System.Drawing.Point(34, 24);
            this.TypeText.Name = "TypeText";
            this.TypeText.Size = new System.Drawing.Size(336, 20);
            this.TypeText.TabIndex = 0;
            // 
            // EditForm
            // 
            this.AcceptButton = this.Ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.Cancl;
            this.ClientSize = new System.Drawing.Size(400, 351);
            this.Controls.Add(this.TypeText);
            this.Controls.Add(this.ProdText);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.CostText);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.WeightText);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.DimensionsText);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.ServAreaText);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.PowSupText);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.VolumeText);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.WidthText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PowerText);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ModelText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ManufactText);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Cancl);
            this.Controls.Add(this.Ok);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Редагування";
            this.Load += new System.EventHandler(this.EditForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox ProdText;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox CostText;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox WeightText;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox DimensionsText;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox ServAreaText;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox PowSupText;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox VolumeText;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox WidthText;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PowerText;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ModelText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ManufactText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Cancl;
        private System.Windows.Forms.Button Ok;
        private System.Windows.Forms.TextBox TypeText;
    }
}