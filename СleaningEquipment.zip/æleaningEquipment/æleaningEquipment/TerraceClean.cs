﻿using System;

namespace СleaningEquipment
{
    public class TerraceClean : CEquip
    {
        public TerraceClean()
        {
        }

        public TerraceClean(string manufacturer, string model, int power, int workingWidth, double productivity, string powerSupply, int volume, int service_area, string dimensions, int weight, double cost) : base(manufacturer, model, power, workingWidth, productivity, powerSupply, volume, service_area, dimensions, weight, cost)
        {
            Type = "Пристрій для ч-ки терас";
        }

        public override int CompareTo(object obj)
        {
            return base.CompareTo(obj);
        }

        public override string OutputInfo()
        {
            return base.OutputInfo();
        }
    }
}
