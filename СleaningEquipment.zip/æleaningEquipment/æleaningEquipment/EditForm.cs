﻿using System;
using System.Windows.Forms;

namespace СleaningEquipment
{
    public partial class EditForm : Form
    {
        CEquip Equip;
        public EditForm(CEquip equip)
        {
            Equip = equip;
            InitializeComponent();
        }

        private void Ok_Click(object sender, EventArgs e)
        {
            Equip.Type = TypeText.Text;
            Equip.Manufacturer = ManufactText.Text;
            Equip.Model = ModelText.Text;
            Equip.Power = Convert.ToInt32(PowerText.Text);
            Equip.WorkingWidth = Convert.ToInt32(WidthText.Text);
            Equip.Productivity = Convert.ToInt32(ProdText.Text);
            Equip.PowerSupply = PowSupText.Text;
            Equip.Volume = Convert.ToInt32(VolumeText.Text);
            Equip.Service_area = Convert.ToInt32(ServAreaText.Text);
            Equip.Dimensions = DimensionsText.Text;
            Equip.Weight = Convert.ToInt32(WeightText.Text);
            Equip.Cost = Convert.ToDouble(CostText.Text);
            DialogResult = DialogResult.OK;
        }

        private void Cancl_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void EditForm_Load(object sender, EventArgs e)
        {
            if (Equip.Type != null && Equip.Cost != 0)
            {
                TypeText.Text = Equip.Type;
                ManufactText.Text = Equip.Manufacturer;
                ModelText.Text = Equip.Model;
                PowerText.Text = Convert.ToString(Equip.Power);
                WidthText.Text = Convert.ToString(Equip.WorkingWidth);
                ProdText.Text = Convert.ToString(Equip.Productivity);
                PowSupText.Text = Equip.PowerSupply;
                VolumeText.Text = Convert.ToString(Equip.Volume);
                ServAreaText.Text = Convert.ToString(Equip.Service_area);
                DimensionsText.Text = Equip.Dimensions;
                WeightText.Text = Convert.ToString(Equip.Weight);
                CostText.Text = Convert.ToString(Equip.Cost);
            }
        }
    }
}
