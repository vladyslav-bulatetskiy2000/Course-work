﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace СleaningEquipment
{
    public partial class AddForm : Form
    {
        public List<CEquip> List;

        public AddForm(List<CEquip> list)
        {
            List = list;

            InitializeComponent();
        }
        
        private void Ok_Click(object sender, EventArgs e)
        {
            try
            {
                switch (typeComboBox.SelectedIndex)
                {
                    case 0:
                        {
                            List.Add(new ElBroom(ManufactText.Text, ModelText.Text,
                            Convert.ToInt32(PowerText.Text), Convert.ToInt32(WidthText.Text),
                            Convert.ToInt32(ProdText.Text), PowSupText.Text, Convert.ToInt32(VolumeText.Text),
                            Convert.ToInt32(ServAreaText.Text), DimensionsText.Text, Convert.ToInt32(WeightText.Text),
                            Convert.ToDouble(CostText.Text)));
                            DialogResult = DialogResult.OK;
                        }
                        break;
                    case 1:
                        {
                            List.Add(new MiniClean(ManufactText.Text, ModelText.Text,
                            Convert.ToInt32(PowerText.Text), Convert.ToInt32(WidthText.Text),
                            Convert.ToInt32(ProdText.Text), PowSupText.Text, Convert.ToInt32(VolumeText.Text),
                            Convert.ToInt32(ServAreaText.Text), DimensionsText.Text, Convert.ToInt32(WeightText.Text),
                            Convert.ToDouble(CostText.Text)));
                            DialogResult = DialogResult.OK;
                        }
                        break;
                    case 2:
                        {
                            List.Add(new ElScraper(ManufactText.Text, ModelText.Text,
                            Convert.ToInt32(PowerText.Text), Convert.ToInt32(WidthText.Text),
                            Convert.ToInt32(ProdText.Text), PowSupText.Text, Convert.ToInt32(VolumeText.Text),
                            Convert.ToInt32(ServAreaText.Text), DimensionsText.Text, Convert.ToInt32(WeightText.Text),
                            Convert.ToDouble(CostText.Text)));
                            DialogResult = DialogResult.OK;
                        }
                        break;
                    case 3:
                        {
                            List.Add(new SteamClean(ManufactText.Text, ModelText.Text,
                            Convert.ToInt32(PowerText.Text), Convert.ToInt32(WidthText.Text),
                            Convert.ToInt32(ProdText.Text), PowSupText.Text, Convert.ToInt32(VolumeText.Text),
                            Convert.ToInt32(ServAreaText.Text), DimensionsText.Text, Convert.ToInt32(WeightText.Text),
                            Convert.ToDouble(CostText.Text)));
                            DialogResult = DialogResult.OK;
                        }
                        break;
                    case 4:
                        {
                            List.Add(new TerraceClean(ManufactText.Text, ModelText.Text,
                            Convert.ToInt32(PowerText.Text), Convert.ToInt32(WidthText.Text),
                            Convert.ToInt32(ProdText.Text), PowSupText.Text, Convert.ToInt32(VolumeText.Text),
                            Convert.ToInt32(ServAreaText.Text), DimensionsText.Text, Convert.ToInt32(WeightText.Text),
                            Convert.ToDouble(CostText.Text)));
                            DialogResult = DialogResult.OK;
                        }
                        break;
                    case 5:
                        {
                            List.Add(new WinCleaner(ManufactText.Text, ModelText.Text,
                            Convert.ToInt32(PowerText.Text), Convert.ToInt32(WidthText.Text),
                            Convert.ToInt32(ProdText.Text), PowSupText.Text, Convert.ToInt32(VolumeText.Text),
                            Convert.ToInt32(ServAreaText.Text), DimensionsText.Text, Convert.ToInt32(WeightText.Text),
                            Convert.ToDouble(CostText.Text)));
                            DialogResult = DialogResult.OK;
                        }
                        break;
                    case 6:
                        {
                            List.Add(new FloorWash(ManufactText.Text, ModelText.Text,
                            Convert.ToInt32(PowerText.Text), Convert.ToInt32(WidthText.Text),
                            Convert.ToInt32(ProdText.Text), PowSupText.Text, Convert.ToInt32(VolumeText.Text),
                            Convert.ToInt32(ServAreaText.Text), DimensionsText.Text, Convert.ToInt32(WeightText.Text),
                            Convert.ToDouble(CostText.Text)));
                            DialogResult = DialogResult.OK;
                        }
                        break;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Сталась помилка: \n{0}",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Cancl_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void typeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ManufactText.Enabled = ModelText.Enabled = PowerText.Enabled = WidthText.Enabled =
            ProdText.Enabled = PowSupText.Enabled = VolumeText.Enabled = ServAreaText.Enabled =
            DimensionsText.Enabled = WeightText.Enabled = CostText.Enabled = true;
        }
    }
}
