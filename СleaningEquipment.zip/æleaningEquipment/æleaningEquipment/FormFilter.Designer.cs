﻿namespace СleaningEquipment
{
    partial class FormFilter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.maxT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.minT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Cancl = new System.Windows.Forms.Button();
            this.Ok = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.maxT);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.minT);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(237, 78);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Вартість";
            // 
            // maxT
            // 
            this.maxT.Location = new System.Drawing.Point(134, 39);
            this.maxT.Name = "maxT";
            this.maxT.Size = new System.Drawing.Size(82, 20);
            this.maxT.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(131, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "до";
            // 
            // minT
            // 
            this.minT.Location = new System.Drawing.Point(23, 39);
            this.minT.Name = "minT";
            this.minT.Size = new System.Drawing.Size(82, 20);
            this.minT.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Від";
            // 
            // Cancl
            // 
            this.Cancl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Cancl.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancl.Location = new System.Drawing.Point(146, 102);
            this.Cancl.Name = "Cancl";
            this.Cancl.Size = new System.Drawing.Size(105, 27);
            this.Cancl.TabIndex = 22;
            this.Cancl.Text = "Скасувати";
            this.Cancl.UseVisualStyleBackColor = true;
            this.Cancl.Click += new System.EventHandler(this.Cancl_Click);
            // 
            // Ok
            // 
            this.Ok.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Ok.Location = new System.Drawing.Point(13, 102);
            this.Ok.Name = "Ok";
            this.Ok.Size = new System.Drawing.Size(105, 27);
            this.Ok.TabIndex = 21;
            this.Ok.Text = "Ок";
            this.Ok.UseVisualStyleBackColor = true;
            this.Ok.Click += new System.EventHandler(this.Ok_Click);
            // 
            // FormFilter
            // 
            this.AcceptButton = this.Ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.Cancl;
            this.ClientSize = new System.Drawing.Size(264, 141);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Cancl);
            this.Controls.Add(this.Ok);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormFilter";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Фільтр";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox maxT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox minT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Cancl;
        private System.Windows.Forms.Button Ok;
    }
}