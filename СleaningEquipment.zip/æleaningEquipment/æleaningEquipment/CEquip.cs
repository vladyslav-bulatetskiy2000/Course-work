﻿using System;

namespace СleaningEquipment
{
    public class CEquip : IComparable
    {
        private string type;
        private string manufacturer;
        private string model;
        private int power;
        private int workingWidth;
        private double productivity;
        private string powerSupply;
        private int volume;
        private int service_area;
        private string dimensions;
        private int weight;
        private double cost;

        public string Type { get => type; set => type = value; }
        public string Manufacturer { get => manufacturer; set => manufacturer = value; }
        public string Model { get => model; set => model = value; }
        public int Power { get => power; set => power = value; }
        public int WorkingWidth { get => workingWidth; set => workingWidth = value; }
        public double Productivity { get => productivity; set => productivity = value; }
        public string PowerSupply { get => powerSupply; set => powerSupply = value; }
        public int Volume { get => volume; set => volume = value; }
        public int Service_area { get => service_area; set => service_area = value; }
        public string Dimensions { get => dimensions; set => dimensions = value; }
        public int Weight { get => weight; set => weight = value; }
        public double Cost { get => cost; set => cost = value; }
        public CEquipSortOrder SortOrder { get; set; }

        public CEquip()
        {
        }

        public CEquip(string manufacturer, string model, int power,
            int workingWidth, double productivity, string powerSupply, int volume,
            int service_area, string dimensions, int weight, double cost)
        {
            Manufacturer = manufacturer;
            Model = model;
            Power = power;
            WorkingWidth = workingWidth;
            Productivity = productivity;
            PowerSupply = powerSupply;
            Volume = volume;
            Service_area = service_area;
            Dimensions = dimensions;
            Weight = weight;
            Cost = cost;
        }

        virtual public int CompareTo(object obj)
        {
            CEquip cEquip = obj as CEquip;
            switch (this.SortOrder)
            {
                case CEquipSortOrder.SortByType:
                    return string.Compare(this.Type, cEquip.Type);
                case CEquipSortOrder.SortByManfct:
                    return string.Compare(this.Manufacturer, cEquip.Manufacturer);
                case CEquipSortOrder.SortByPower:
                    return (this.Power > cEquip.Power ? 1 : (this.Power < cEquip.Power ? -1 : 0));
                case CEquipSortOrder.SortByWW:
                    return (this.WorkingWidth > cEquip.WorkingWidth ? 1 : (this.WorkingWidth < cEquip.WorkingWidth ? -1 : 0));
                case CEquipSortOrder.SortByProd:
                    return (this.Productivity > cEquip.Productivity ? 1 : (this.Productivity < cEquip.Productivity ? -1 : 0));
                case CEquipSortOrder.SortBySA:
                    return (this.Service_area > cEquip.Service_area ? 1 : (this.Service_area < cEquip.Service_area ? -1 : 0));
                case CEquipSortOrder.SortByCost:
                    return (this.Cost > cEquip.Cost ? 1 : (this.Cost < cEquip.Cost ? -1 : 0));
                default:
                    return string.Compare(this.Manufacturer, cEquip.Manufacturer);
            }
        }

        public virtual string OutputInfo()
        {
            return $"{Type}\t{Manufacturer}\t{Model}\t{Power}\t{WorkingWidth}\t{Productivity}\t{PowerSupply}\t{Volume}\t" +
                $"{Service_area}\t{Dimensions}\t{Weight}\t{Cost}\t";
        }
    }
    public enum CEquipSortOrder
    {
        SortByType = 1, SortByManfct = 2, SortByPower = 3, SortByWW = 4, SortByProd = 5, SortBySA = 6, SortByCost = 7
    };
}
