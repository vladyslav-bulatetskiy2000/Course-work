﻿using System;
using System.Windows.Forms;

namespace СleaningEquipment
{
    public partial class FormFilter : Form
    {
        public int Min;
        public int Max;

        public FormFilter(int min, int max)
        {
            Min = min;
            Max = max;

            InitializeComponent();
        }

        private void Ok_Click(object sender, EventArgs e)
        {
            if (!Int32.TryParse(minT.Text, out Min))
            {
                MessageBox.Show("Неправильно введено число!", "",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                minT.Focus();
                return;
            }
            if (!Int32.TryParse(maxT.Text, out Max))
            {
                MessageBox.Show("Неправильно введено число!", "",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                maxT.Focus();
                return;
            }
            DialogResult = DialogResult.OK;
        }

        private void Cancl_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel; 
        }
    }
}
