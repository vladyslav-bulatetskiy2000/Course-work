﻿namespace СleaningEquipment
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ElQuipGV = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mictAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.mictEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.mictDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.AddButton = new System.Windows.Forms.ToolStripButton();
            this.EditButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.DeleteButton = new System.Windows.Forms.ToolStripButton();
            this.ClearButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.OpenTextButton = new System.Windows.Forms.ToolStripButton();
            this.SaveTextButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.FilterButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.SortComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.FileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ExitItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddNew = new System.Windows.Forms.ToolStripMenuItem();
            this.EditItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.DeleteItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ClearAllItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.SeachItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.ElQuipGV)).BeginInit();
            this.contextMenuStrip.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // ElQuipGV
            // 
            this.ElQuipGV.AllowUserToAddRows = false;
            this.ElQuipGV.AllowUserToDeleteRows = false;
            this.ElQuipGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ElQuipGV.ContextMenuStrip = this.contextMenuStrip;
            this.ElQuipGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ElQuipGV.Location = new System.Drawing.Point(0, 49);
            this.ElQuipGV.MultiSelect = false;
            this.ElQuipGV.Name = "ElQuipGV";
            this.ElQuipGV.ReadOnly = true;
            this.ElQuipGV.Size = new System.Drawing.Size(1046, 401);
            this.ElQuipGV.TabIndex = 11;
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mictAdd,
            this.mictEdit,
            this.toolStripSeparator9,
            this.mictDelete});
            this.contextMenuStrip.Name = "cmsDataGrid";
            this.contextMenuStrip.Size = new System.Drawing.Size(127, 76);
            // 
            // mictAdd
            // 
            this.mictAdd.Image = global::СleaningEquipment.Properties.Resources.sign_add_icon;
            this.mictAdd.Name = "mictAdd";
            this.mictAdd.Size = new System.Drawing.Size(126, 22);
            this.mictAdd.Text = "Додати";
            this.mictAdd.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // mictEdit
            // 
            this.mictEdit.Image = global::СleaningEquipment.Properties.Resources.pencil_icon;
            this.mictEdit.Name = "mictEdit";
            this.mictEdit.Size = new System.Drawing.Size(126, 22);
            this.mictEdit.Text = "Змінити";
            this.mictEdit.Click += new System.EventHandler(this.EditButton_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(123, 6);
            // 
            // mictDelete
            // 
            this.mictDelete.Image = global::СleaningEquipment.Properties.Resources.sign_delete_icon;
            this.mictDelete.Name = "mictDelete";
            this.mictDelete.Size = new System.Drawing.Size(126, 22);
            this.mictDelete.Text = "Видалити";
            this.mictDelete.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddButton,
            this.EditButton,
            this.toolStripSeparator1,
            this.DeleteButton,
            this.ClearButton,
            this.toolStripSeparator2,
            this.OpenTextButton,
            this.SaveTextButton,
            this.toolStripSeparator4,
            this.FilterButton,
            this.toolStripLabel2,
            this.SortComboBox});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1046, 25);
            this.toolStrip1.TabIndex = 10;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // AddButton
            // 
            this.AddButton.Image = global::СleaningEquipment.Properties.Resources.sign_add_icon;
            this.AddButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(66, 22);
            this.AddButton.Text = "Додати";
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // EditButton
            // 
            this.EditButton.Image = global::СleaningEquipment.Properties.Resources.pencil_icon;
            this.EditButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(87, 22);
            this.EditButton.Text = "Редагувати";
            this.EditButton.ToolTipText = "Редагувати запис";
            this.EditButton.Click += new System.EventHandler(this.EditButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Image = global::СleaningEquipment.Properties.Resources.sign_delete_icon;
            this.DeleteButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(79, 22);
            this.DeleteButton.Text = "Видалити";
            this.DeleteButton.ToolTipText = "Видалити запис";
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Image = global::СleaningEquipment.Properties.Resources.sign_error_icon;
            this.ClearButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(80, 22);
            this.ClearButton.Text = "Очистити";
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // OpenTextButton
            // 
            this.OpenTextButton.Image = global::СleaningEquipment.Properties.Resources.box_out_icon;
            this.OpenTextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OpenTextButton.Name = "OpenTextButton";
            this.OpenTextButton.Size = new System.Drawing.Size(133, 22);
            this.OpenTextButton.Text = "Прочитати з файлу";
            this.OpenTextButton.Click += new System.EventHandler(this.OpenTextButton_Click);
            // 
            // SaveTextButton
            // 
            this.SaveTextButton.Image = global::СleaningEquipment.Properties.Resources.floppy_icon;
            this.SaveTextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaveTextButton.Name = "SaveTextButton";
            this.SaveTextButton.Size = new System.Drawing.Size(118, 22);
            this.SaveTextButton.Text = "Зберегти в файл";
            this.SaveTextButton.Click += new System.EventHandler(this.SaveTextButton_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // FilterButton
            // 
            this.FilterButton.Image = global::СleaningEquipment.Properties.Resources.Funnel_icon;
            this.FilterButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.FilterButton.Name = "FilterButton";
            this.FilterButton.Size = new System.Drawing.Size(64, 22);
            this.FilterButton.Text = "Фільтр";
            this.FilterButton.Click += new System.EventHandler(this.FilterButton_Click);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(81, 22);
            this.toolStripLabel2.Text = "Сортувати за:";
            // 
            // SortComboBox
            // 
            this.SortComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SortComboBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.SortComboBox.Items.AddRange(new object[] {
            "типом техніки",
            "виробником",
            "потужністю",
            "робочою шириною",
            "продуктивністю",
            "площею обслуговування",
            "вартістю"});
            this.SortComboBox.Name = "SortComboBox";
            this.SortComboBox.Size = new System.Drawing.Size(121, 25);
            this.SortComboBox.ToolTipText = "Сортувати за";
            this.SortComboBox.SelectedIndexChanged += new System.EventHandler(this.SortComboBox_SelectedIndexChanged);
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileMenuItem,
            this.EditMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1046, 24);
            this.menuStrip.TabIndex = 9;
            this.menuStrip.Text = "menuStrip1";
            // 
            // FileMenuItem
            // 
            this.FileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenItem,
            this.SaveItem,
            this.toolStripSeparator6,
            this.ExitItem});
            this.FileMenuItem.Name = "FileMenuItem";
            this.FileMenuItem.Size = new System.Drawing.Size(48, 20);
            this.FileMenuItem.Text = "Файл";
            // 
            // OpenItem
            // 
            this.OpenItem.Image = global::СleaningEquipment.Properties.Resources.box_out_icon;
            this.OpenItem.Name = "OpenItem";
            this.OpenItem.Size = new System.Drawing.Size(124, 22);
            this.OpenItem.Text = "Відкрити";
            this.OpenItem.Click += new System.EventHandler(this.OpenTextButton_Click);
            // 
            // SaveItem
            // 
            this.SaveItem.Image = global::СleaningEquipment.Properties.Resources.floppy_icon;
            this.SaveItem.Name = "SaveItem";
            this.SaveItem.Size = new System.Drawing.Size(124, 22);
            this.SaveItem.Text = "Зберегти";
            this.SaveItem.Click += new System.EventHandler(this.SaveTextButton_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(121, 6);
            // 
            // ExitItem
            // 
            this.ExitItem.Name = "ExitItem";
            this.ExitItem.Size = new System.Drawing.Size(124, 22);
            this.ExitItem.Text = "Вихід";
            // 
            // EditMenuItem
            // 
            this.EditMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddNew,
            this.EditItem,
            this.toolStripSeparator7,
            this.DeleteItem,
            this.ClearAllItem,
            this.toolStripSeparator8,
            this.SeachItem});
            this.EditMenuItem.Name = "EditMenuItem";
            this.EditMenuItem.Size = new System.Drawing.Size(59, 20);
            this.EditMenuItem.Text = "Правка";
            // 
            // AddNew
            // 
            this.AddNew.Image = global::СleaningEquipment.Properties.Resources.sign_add_icon;
            this.AddNew.Name = "AddNew";
            this.AddNew.Size = new System.Drawing.Size(145, 22);
            this.AddNew.Text = "Додати";
            this.AddNew.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // EditItem
            // 
            this.EditItem.Image = global::СleaningEquipment.Properties.Resources.pencil_icon;
            this.EditItem.Name = "EditItem";
            this.EditItem.Size = new System.Drawing.Size(145, 22);
            this.EditItem.Text = "Редагувати";
            this.EditItem.Click += new System.EventHandler(this.EditButton_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(142, 6);
            // 
            // DeleteItem
            // 
            this.DeleteItem.Image = global::СleaningEquipment.Properties.Resources.sign_delete_icon;
            this.DeleteItem.Name = "DeleteItem";
            this.DeleteItem.Size = new System.Drawing.Size(145, 22);
            this.DeleteItem.Text = "Видалити";
            this.DeleteItem.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // ClearAllItem
            // 
            this.ClearAllItem.Image = global::СleaningEquipment.Properties.Resources.sign_error_icon;
            this.ClearAllItem.Name = "ClearAllItem";
            this.ClearAllItem.Size = new System.Drawing.Size(145, 22);
            this.ClearAllItem.Text = "Очистити всі";
            this.ClearAllItem.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(142, 6);
            // 
            // SeachItem
            // 
            this.SeachItem.Image = global::СleaningEquipment.Properties.Resources.Funnel_icon;
            this.SeachItem.Name = "SeachItem";
            this.SeachItem.Size = new System.Drawing.Size(145, 22);
            this.SeachItem.Text = "Фільтрувати";
            this.SeachItem.Click += new System.EventHandler(this.FilterButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1046, 450);
            this.Controls.Add(this.ElQuipGV);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Електрична прибиральна техніка";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ElQuipGV)).EndInit();
            this.contextMenuStrip.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ElQuipGV;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem mictAdd;
        private System.Windows.Forms.ToolStripMenuItem mictEdit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem mictDelete;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton AddButton;
        private System.Windows.Forms.ToolStripButton EditButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton DeleteButton;
        private System.Windows.Forms.ToolStripButton ClearButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton OpenTextButton;
        private System.Windows.Forms.ToolStripButton SaveTextButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton FilterButton;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox SortComboBox;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem FileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpenItem;
        private System.Windows.Forms.ToolStripMenuItem SaveItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem ExitItem;
        private System.Windows.Forms.ToolStripMenuItem EditMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddNew;
        private System.Windows.Forms.ToolStripMenuItem EditItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem DeleteItem;
        private System.Windows.Forms.ToolStripMenuItem ClearAllItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem SeachItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

