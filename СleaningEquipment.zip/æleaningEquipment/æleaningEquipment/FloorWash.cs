﻿using System;

namespace СleaningEquipment
{
    public class FloorWash : CEquip
    {
        public FloorWash() { }

        public FloorWash(string manufacturer, string model, int power, int workingWidth, double productivity, string powerSupply, int volume, int service_area, string dimensions, int weight, double cost) : base(manufacturer, model, power, workingWidth, productivity, powerSupply, volume, service_area, dimensions, weight, cost)
        {
            Type = "Підлогомийна машина";
        }

        public override int CompareTo(object obj)
        {
            return base.CompareTo(obj);
        }

        public override string OutputInfo()
        {
            return base.OutputInfo();
        }
    }
}
